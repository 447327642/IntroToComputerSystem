/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_244(unsigned x)
{
    return x + 3281017082U;
}

void setval_277(unsigned *p)
{
    *p = 2428995912U;
}

void setval_222(unsigned *p)
{
    *p = 3339274404U;
}

void setval_250(unsigned *p)
{
    *p = 2009305176U;
}

unsigned getval_434()
{
    return 2428996424U;
}

unsigned addval_499(unsigned x)
{
    return x + 3281031384U;
}

unsigned addval_387(unsigned x)
{
    return x + 2425510133U;
}

void setval_416(unsigned *p)
{
    *p = 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_362(unsigned x)
{
    return x + 3224949129U;
}

void setval_285(unsigned *p)
{
    *p = 3250751947U;
}

unsigned getval_177()
{
    return 2447411528U;
}

void setval_331(unsigned *p)
{
    *p = 3252717896U;
}

void setval_423(unsigned *p)
{
    *p = 3523789449U;
}

unsigned addval_275(unsigned x)
{
    return x + 3224424841U;
}

unsigned getval_378()
{
    return 3531919753U;
}

unsigned getval_296()
{
    return 2464188744U;
}

unsigned addval_443(unsigned x)
{
    return x + 3674787465U;
}

void setval_141(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_435(unsigned x)
{
    return x + 2425409933U;
}

unsigned getval_409()
{
    return 3229143433U;
}

unsigned getval_272()
{
    return 3524838025U;
}

unsigned addval_271(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_386()
{
    return 2446231996U;
}

unsigned getval_465()
{
    return 3286272840U;
}

unsigned addval_289(unsigned x)
{
    return x + 3224948361U;
}

unsigned addval_179(unsigned x)
{
    return x + 3285096759U;
}

unsigned addval_477(unsigned x)
{
    return x + 3469301311U;
}

unsigned getval_330()
{
    return 3267528989U;
}

unsigned addval_194(unsigned x)
{
    return x + 3348152969U;
}

unsigned addval_123(unsigned x)
{
    return x + 3281044104U;
}

unsigned getval_368()
{
    return 3682910857U;
}

unsigned getval_200()
{
    return 3375943369U;
}

void setval_201(unsigned *p)
{
    *p = 3286272344U;
}

unsigned addval_158(unsigned x)
{
    return x + 3680554633U;
}

unsigned addval_306(unsigned x)
{
    return x + 3682914761U;
}

void setval_193(unsigned *p)
{
    *p = 3526938313U;
}

unsigned getval_340()
{
    return 3286272330U;
}

void setval_181(unsigned *p)
{
    *p = 3225997705U;
}

void setval_403(unsigned *p)
{
    *p = 3682910729U;
}

unsigned addval_310(unsigned x)
{
    return x + 2446428585U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
